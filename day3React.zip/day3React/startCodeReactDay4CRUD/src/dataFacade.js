const URL = "http://localhost:3456/api";


function handleHttpErrors(res) {
  if (!res.ok) {
    throw Error(res.statusText);
  }
  return res.json();
}

class DataFacade {
  
  getPersons() {
    return fetch(URL).then(handleHttpErrors)
  }

 }

export default new DataFacade();