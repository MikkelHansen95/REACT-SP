import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import App2 from './App2';
import Toggle from './Toggle';
//import ListDemo from './ListDemo';
import Clock from './clock';

//ReactDOM.render(<App />,document.getElementById('root'));
ReactDOM.render(<App2 />,document.getElementById('root'));
ReactDOM.render(<App2 />,document.getElementById('root'));
ReactDOM.render(<Clock />,document.getElementById('root'));
//ReactDOM.render(<Toggle />,document.getElementById('root'));
//ReactDOM.render(<ListDemo />, document.getElementById('root'));