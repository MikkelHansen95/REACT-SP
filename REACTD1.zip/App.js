import React, { Component } from 'react';
import upper, {text1,text2,text3} from "./dataStore1";
import person from "./dataStore2";
import Clock from "./clock.js";


//function App(){
 // return (
 //   <div>
 //     <p> {clock}</p>
 // </div>
 // )
//}



class App extends Component {
  render() {
    return (
      <div>
      <p>{upper("please uppercase me")}</p>
       <p>{Clock} </p>
       <p>{person.firstName}</p>
       <p>{person.email}</p>
      </div>
    )
  }
}



export default App
