import React, {Component} from 'react';

class Clock extends React.Component {
    constructor(props) {
      super(props);
      this.state = {message: "Se min nye text" ,date: new Date(), sleep : 1000};
    }
  
    tick() {
        this.setState(sleep => ({
            date : new Date()
          }));
      }

  

    componentDidMount() {
        this.interval = setInterval(() => this.tick(), this.state.sleep);
        console.log("I am the componentDidMount");
    
    }
  
    componentWillUnmount() {
        console.log("I am the componentDidUnmount");
    }
    componentDidUpdate(){
        console.log("I am the update");
    }
    componentDidCatch(){
      console.log("I am the catch ;-)");
    }

    render() {
      return (
        <div>
          <h1>{this.state.message}</h1>
          <h2>It is: {this.state.date.toLocaleTimeString()}.</h2>
        </div>
      );
    }
  }

  export default Clock