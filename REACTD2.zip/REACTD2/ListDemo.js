import React from 'react';
import car from './cars';
import cars from './cars';

function NumberList(props) {
    const numbers = props.numbers;
    const listItems = numbers.map((number,index) =>
      <li key ={index}>{number}</li>
    );
    return (
      <ul>{listItems}</ul>
    );
  }
  
  function ListItem(props) {
    // Correct! There is no need to specify the key here:
    return <li>{props.value}</li>;
  }

 



  function NumberTable(props) {
    const cars = props.cars
    const listItems = cars.cars.map((car) =>
    <tbody key = {car.id}>
      <tr>
        <td>{car.id}</td>
        <td>{car.make}</td>
        <td>{car.model}</td>
        <td>{car.year}</td>
      </tr>
      </tbody>
    );
    return (
      <table>{listItems}</table>
    );
  }

class ListDemo extends React.Component {
    constructor(props){
        super(props);
        this.state = {number: [1,2,3,4,5]}
    }
    render() {
      return (
          <div>
            <h2> <NumberTable cars = {car}/> </h2>
          </div>
      )           
    }
  }

  export default ListDemo